new Vue({
  data: function () {
    return {
      users: [
        {
          name: '张三',
          number: '2222222222222222',
          class: '电子与通信工程',
          avatar: './imgs/avatar0.jpg'
        },
        {
          name: '李四',
          number: '201822614023',
          class: '电子与通信工程',
          avatar: './imgs/avatar1.jpg'
        },
        {
          name: '王五',
          number: '201822614013',
          class: '电子与通信工程',
          avatar: './imgs/avatar2.jpg'
        }
      ],
      userNum: 0,
      today: {
        year: null,
        month: null,
        date: null,
        hours: null,
        minutes: null,
        seconds: null
      },
      count: 180,
      showTips: false,
      localShowTips: localStorage.getItem('tj') == 0 ? false : true
    }
  },
  mounted: function () {
    var that = this;
    // 初始化设置用户Number
    this.setUserNum();
    // 初始化设置一次当前时闿
    this.setNowTime();
    // 1s修改一次当前时闿
    this.interTime = setInterval(this.setNowTime, 1000);
    // 初始化设置倒计旿
    this.setCount();
    // 初始化延迟显示Tips
    setTimeout(function () {
      if(!localStorage.getItem('tj')){
        that.showTips = true;
      }
    }, 2000);
  },
  beforeDistory: function () {
    clearInterval(this.interTime);
    clearInterval(this.interCount);
  },
  methods: {
    setUserNum: function () {
      var url = location.href;
      var query = url.split('?')[1];
      if(query){
        var num = query.split('=')[1];
        this.userNum = parseInt(num);
      }
    },
    setNowTime: function () {
      var dt = new Date();
      var year = dt.getFullYear();
      var month = dt.getMonth() + 1;
      var date = dt.getDate();
      var hours = dt.getHours();
      var minutes = dt.getMinutes();
      var seconds = dt.getSeconds();
      this.today.year = year;
      this.today.month = month >= 10 ? month : '0' + month;
      this.today.date = date >= 10 ? date : '0' + date;
      this.today.hours = hours >= 10 ? hours : '0' + hours;
      this.today.minutes = minutes >= 10 ? minutes : '0' + minutes;
      this.today.seconds = seconds >= 10 ? seconds : '0' + seconds;
    },
    setCount: function () {
      var that = this;
      var count = this.count;
      setTimeout(function () {
        that.interCount = setInterval(function () {
          if(that.count <= 1){
            that.count = count;
          }else{
            that.count--;
          }
        }, 1000);
      }, 500)
    },
    closeMask: function () {
      this.showTips = false;
      localStorage.setItem('tj', 0);
    }
  }
}).$mount('#app');